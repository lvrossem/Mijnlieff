package mijnlieff.models;

import mijnlieff.pieces.Piece;

import java.util.ArrayList;

public interface MijnlieffModel {

    void fireInvalidationEvent();

}
